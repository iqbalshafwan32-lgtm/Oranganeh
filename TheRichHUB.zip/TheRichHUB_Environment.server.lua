--[[
	TheRichHUB - Environment (Script)
	Letakkan di: ServerScriptService > TheRichHUB_Environment (Script biasa)
	Fungsi: langit biru, awan, pencahayaan sinematik + memuat asset 70693066629625
]]

local Lighting = game:GetService("Lighting")
local InsertService = game:GetService("InsertService")

local ASSET_ID = 70693066629625

local function ensure(class, name, props)
	local obj = Lighting:FindFirstChild(name)
	if not obj then
		obj = Instance.new(class)
		obj.Name = name
		obj.Parent = Lighting
	end
	for k, v in pairs(props) do
		obj[k] = v
	end
	return obj
end

-- 1. Pencahayaan sinematik
Lighting.ClockTime = 14.5
Lighting.Brightness = 2.6
Lighting.GlobalShadows = true
Lighting.Ambient = Color3.fromRGB(90, 110, 150)
Lighting.OutdoorAmbient = Color3.fromRGB(120, 140, 180)
Lighting.ColorShift_Top = Color3.fromRGB(255, 244, 225)
Lighting.EnvironmentDiffuseScale = 1
Lighting.EnvironmentSpecularScale = 1

ensure("Atmosphere", "TRH_Atmosphere", {
	Density = 0.28, Offset = 0.25,
	Color = Color3.fromRGB(199, 220, 255),
	Decay = Color3.fromRGB(106, 150, 214),
	Glare = 0.2, Haze = 1.2,
})
ensure("BloomEffect", "TRH_Bloom", { Intensity = 0.35, Size = 24, Threshold = 1.1 })
ensure("ColorCorrectionEffect", "TRH_Color", {
	Brightness = 0.02, Contrast = 0.12, Saturation = 0.15,
	TintColor = Color3.fromRGB(235, 244, 255),
})
ensure("SunRaysEffect", "TRH_Rays", { Intensity = 0.08, Spread = 0.6 })

-- 2. Awan (Terrain Clouds)
local terrain = workspace:FindFirstChildOfClass("Terrain")
if terrain then
	local clouds = terrain:FindFirstChildOfClass("Clouds") or Instance.new("Clouds")
	clouds.Cover = 0.55
	clouds.Density = 0.6
	clouds.Color = Color3.fromRGB(255, 255, 255)
	clouds.Parent = terrain
end

-- 3. Skybox default (fallback) bila belum ada
if not Lighting:FindFirstChildOfClass("Sky") then
	local sky = Instance.new("Sky")
	sky.Name = "TRH_Sky"
	sky.StarCount = 0
	sky.CelestialBodiesShown = true
	sky.Parent = Lighting
end

-- 4. Muat asset secara adaptif (Sky -> Lighting, model/lingkungan -> Workspace)
local ok, model = pcall(function()
	return InsertService:LoadAsset(ASSET_ID)
end)

if not ok or not model then
	warn("[TheRichHUB] Asset gagal dimuat (harus gratis/public atau milik Anda). "
		.. "Solusi: masukkan manual lewat Toolbox, script ini akan tetap memakai Sky yang ada. Error: "
		.. tostring(model))
	return
end

-- Sky
local newSky = model:FindFirstChildWhichIsA("Sky", true)
if newSky then
	for _, old in ipairs(Lighting:GetChildren()) do
		if old:IsA("Sky") then old:Destroy() end
	end
	newSky.Parent = Lighting
end

-- Efek lighting bawaan asset
for _, d in ipairs(model:GetDescendants()) do
	if d:IsA("Atmosphere") or d:IsA("PostEffect") or d:IsA("Clouds") then
		d.Parent = d:IsA("Clouds") and terrain or Lighting
	end
end

-- Sisa objek 3D -> elemen dunia
local world = Instance.new("Folder")
world.Name = "TheRichHUB_World"
for _, child in ipairs(model:GetChildren()) do
	child.Parent = world
end
world.Parent = workspace
model:Destroy()

print("[TheRichHUB] Environment siap.")
