--[[
	TheRichHUB - Client UI (LocalScript)
	Letakkan di: StarterGui > TheRichHUB_Client (LocalScript)
	Tema: iOS Glassmorphism + Gaming Dashboard
]]

----------------------------------------------------------------------
-- 1. SERVICES
----------------------------------------------------------------------
local Players = game:GetService("Players")
local TweenService = game:GetService("TweenService")
local UserInputService = game:GetService("UserInputService")
local Lighting = game:GetService("Lighting")
local TeleportService = game:GetService("TeleportService")

local player = Players.LocalPlayer
local playerGui = player:WaitForChild("PlayerGui")

if playerGui:FindFirstChild("TheRichHUB") then
	playerGui.TheRichHUB:Destroy()
end

----------------------------------------------------------------------
-- 2. CONFIG & THEME (ubah di sini untuk kustomisasi)
----------------------------------------------------------------------
local CONFIG = {
	Name = "TheRichHUB",
	Subtitle = "PREMIUM  •  GLASS  •  INTERFACE",
	ProfileSubtitle = "DARLING",

	-- Upload gambar anime milik sendiri / berlisensi ke Creator Hub,
	-- lalu isi dengan "rbxassetid://ID_GAMBAR". Kosong = disembunyikan.
	AnimeImage = "",

	Stats = {
		Bounty = "30M",
		Level = "2800",
		StartSeconds = 2 * 60 + 54, -- 2:54 (berjalan otomatis)
		Health = 67,                -- persen
	},
	UseLiveHealth = false, -- true = ikuti Humanoid.Health pemain

	ToggleKey = Enum.KeyCode.RightControl,
	BlurSize = 10,
	DesignSize = Vector2.new(960, 540), -- rasio 16:9
}

local Theme = {
	Accent = Color3.fromRGB(64, 156, 255),
	Deep = Color3.fromRGB(8, 16, 34),
	Glass = Color3.fromRGB(20, 38, 74),
	Text = Color3.fromRGB(255, 255, 255),
	SubText = Color3.fromRGB(176, 190, 214),
	Off = Color3.fromRGB(80, 92, 116),
	Font = Enum.Font.GothamMedium,
	FontBold = Enum.Font.GothamBold,
}

local State = {
	Accent = Theme.Accent,
	Page = nil,
	Minimized = false,
	Alive = true,
	BlurEnabled = true,
	ScaleMul = 1,
}

local connections = {}
local accentListeners = {}

----------------------------------------------------------------------
-- 3. UTIL
----------------------------------------------------------------------
local function make(class, props, parent)
	local inst = Instance.new(class)
	for k, v in pairs(props or {}) do
		inst[k] = v
	end
	inst.Parent = parent
	return inst
end

local function tween(inst, duration, goal, style, direction)
	local tw = TweenService:Create(
		inst,
		TweenInfo.new(duration, style or Enum.EasingStyle.Quint, direction or Enum.EasingDirection.Out),
		goal
	)
	tw:Play()
	return tw
end

local function connect(signal, fn)
	local c = signal:Connect(fn)
	table.insert(connections, c)
	return c
end

local function merge(base, extra)
	for k, v in pairs(extra or {}) do
		base[k] = v
	end
	return base
end

local function onAccent(fn)
	table.insert(accentListeners, fn)
	fn(State.Accent)
end

local function setAccent(color)
	State.Accent = color
	for _, fn in ipairs(accentListeners) do
		fn(color)
	end
end

local function label(parent, text, size, props)
	return make("TextLabel", merge({
		BackgroundTransparency = 1,
		Text = text,
		TextSize = size,
		Font = Theme.Font,
		TextColor3 = Theme.Text,
		TextXAlignment = Enum.TextXAlignment.Left,
		TextYAlignment = Enum.TextYAlignment.Center,
		Size = UDim2.new(1, 0, 0, size + 4),
	}, props), parent)
end

local function card(parent, props)
	local frame = make("Frame", merge({
		BackgroundColor3 = Theme.Glass,
		BackgroundTransparency = 0.55,
		BorderSizePixel = 0,
	}, props), parent)
	make("UICorner", { CornerRadius = UDim.new(0, 16) }, frame)
	make("UIStroke", { Color = Color3.new(1, 1, 1), Transparency = 0.82, Thickness = 1 }, frame)
	return frame
end

local function pressEffect(button)
	local s = make("UIScale", { Scale = 1 }, button)
	connect(button.MouseButton1Down, function()
		tween(s, 0.12, { Scale = 0.96 })
	end)
	connect(button.MouseButton1Up, function()
		tween(s, 0.2, { Scale = 1 }, Enum.EasingStyle.Back)
	end)
	connect(button.MouseLeave, function()
		tween(s, 0.2, { Scale = 1 })
	end)
end

local function createLogo(parent, size)
	-- Logo diamond bergaya (bukan aset bermerek), aman dari masalah hak cipta.
	local outer = make("Frame", {
		Size = UDim2.fromOffset(size, size),
		AnchorPoint = Vector2.new(0.5, 0.5),
		Position = UDim2.fromScale(0.5, 0.5),
		Rotation = 12,
		BackgroundColor3 = Color3.new(1, 1, 1),
		BorderSizePixel = 0,
	}, parent)
	make("UICorner", { CornerRadius = UDim.new(0, math.floor(size * 0.22)) }, outer)
	make("UIGradient", {
		Color = ColorSequence.new(Color3.fromRGB(120, 190, 255), Color3.fromRGB(40, 110, 230)),
		Rotation = 90,
	}, outer)
	local inner = make("Frame", {
		Size = UDim2.fromScale(0.32, 0.32),
		AnchorPoint = Vector2.new(0.5, 0.5),
		Position = UDim2.fromScale(0.5, 0.5),
		BackgroundColor3 = Theme.Deep,
		BorderSizePixel = 0,
	}, outer)
	make("UICorner", { CornerRadius = UDim.new(0, 3) }, inner)
	return outer
end

----------------------------------------------------------------------
-- 4. ROOT GUI, BLUR, SCALE
----------------------------------------------------------------------
local gui = make("ScreenGui", {
	Name = "TheRichHUB",
	ResetOnSpawn = false,
	IgnoreGuiInset = true,
	ZIndexBehavior = Enum.ZIndexBehavior.Sibling,
	DisplayOrder = 100,
}, playerGui)

local blur = make("BlurEffect", { Name = "TheRichHUB_Blur", Size = 0 }, Lighting)

local holder = make("Frame", {
	Name = "Holder",
	AnchorPoint = Vector2.new(0.5, 0.5),
	Position = UDim2.fromScale(0.5, 0.5),
	Size = UDim2.fromOffset(CONFIG.DesignSize.X, CONFIG.DesignSize.Y),
	BackgroundTransparency = 1,
}, gui)

local responsiveScale = make("UIScale", { Scale = 1 }, holder)

local function updateResponsiveScale()
	local cam = workspace.CurrentCamera
	if not cam then return end
	local vp = cam.ViewportSize
	local s = math.min(vp.X / (CONFIG.DesignSize.X + 80), vp.Y / (CONFIG.DesignSize.Y + 60))
	responsiveScale.Scale = math.clamp(s, 0.45, 1.5) * State.ScaleMul
end

local function updateBlur()
	local target = (State.BlurEnabled and not State.Minimized and State.Alive) and CONFIG.BlurSize or 0
	tween(blur, 0.4, { Size = target })
end

----------------------------------------------------------------------
-- 5. MAIN WINDOW (CanvasGroup = fade seluruh UI sekaligus)
----------------------------------------------------------------------
local main = make("CanvasGroup", {
	Name = "Main",
	Size = UDim2.fromScale(1, 1),
	BackgroundColor3 = Color3.fromRGB(12, 26, 56),
	BackgroundTransparency = 0.22,
	BorderSizePixel = 0,
	GroupTransparency = 1,
}, holder)
make("UICorner", { CornerRadius = UDim.new(0, 26) }, main)
make("UIStroke", { Color = Color3.new(1, 1, 1), Transparency = 0.7, Thickness = 1.2 }, main)
make("UIGradient", {
	Color = ColorSequence.new(Color3.fromRGB(34, 70, 140), Color3.fromRGB(6, 12, 28)),
	Rotation = 125,
}, main)
local mainScale = make("UIScale", { Scale = 0.92 }, main)

-- Cahaya lembut (glow) di pojok
local function glow(pos, anchor)
	local g = make("Frame", {
		Size = UDim2.fromOffset(380, 380),
		AnchorPoint = anchor,
		Position = pos,
		BackgroundColor3 = State.Accent,
		BackgroundTransparency = 0.86,
		BorderSizePixel = 0,
	}, main)
	make("UICorner", { CornerRadius = UDim.new(1, 0) }, g)
	onAccent(function(c) g.BackgroundColor3 = c end)
end
glow(UDim2.fromScale(1, 0), Vector2.new(0.5, 0.5))
glow(UDim2.fromScale(0, 1), Vector2.new(0.5, 0.5))

----------------------------------------------------------------------
-- 6. HEADER
----------------------------------------------------------------------
local header = make("Frame", {
	Name = "Header",
	Size = UDim2.new(1, 0, 0, 56),
	BackgroundTransparency = 1,
	Active = true,
}, main)

make("Frame", {
	AnchorPoint = Vector2.new(0, 1),
	Position = UDim2.fromScale(0, 1),
	Size = UDim2.new(1, 0, 0, 1),
	BackgroundColor3 = Color3.new(1, 1, 1),
	BackgroundTransparency = 0.88,
	BorderSizePixel = 0,
}, header)

local logoHolder = make("Frame", {
	Position = UDim2.fromOffset(18, 10),
	Size = UDim2.fromOffset(36, 36),
	BackgroundTransparency = 1,
}, header)
createLogo(logoHolder, 28)

label(header, CONFIG.Name, 20, {
	Font = Theme.FontBold,
	Position = UDim2.fromOffset(64, 8),
	Size = UDim2.fromOffset(300, 22),
})
label(header, CONFIG.Subtitle, 10, {
	Position = UDim2.fromOffset(64, 31),
	Size = UDim2.fromOffset(300, 14),
	TextColor3 = Theme.SubText,
})

local function headerButton(text, xOffset, hoverColor)
	local b = make("TextButton", {
		AnchorPoint = Vector2.new(1, 0.5),
		Position = UDim2.new(1, xOffset, 0.5, 0),
		Size = UDim2.fromOffset(32, 32),
		BackgroundColor3 = Color3.new(1, 1, 1),
		BackgroundTransparency = 0.9,
		Text = text,
		TextSize = 15,
		Font = Theme.FontBold,
		TextColor3 = Theme.Text,
		AutoButtonColor = false,
	}, header)
	make("UICorner", { CornerRadius = UDim.new(1, 0) }, b)
	make("UIStroke", { Color = Color3.new(1, 1, 1), Transparency = 0.85 }, b)
	pressEffect(b)
	connect(b.MouseEnter, function()
		tween(b, 0.2, { BackgroundColor3 = hoverColor, BackgroundTransparency = 0.4 })
	end)
	connect(b.MouseLeave, function()
		tween(b, 0.2, { BackgroundColor3 = Color3.new(1, 1, 1), BackgroundTransparency = 0.9 })
	end)
	return b
end

local minimizeBtn = headerButton("–", -58, Theme.Accent)
local closeBtn = headerButton("✕", -18, Color3.fromRGB(255, 80, 90))

-- Drag window (PC & mobile)
do
	local dragging, dragStart, startPos
	connect(header.InputBegan, function(input)
		if input.UserInputType == Enum.UserInputType.MouseButton1
			or input.UserInputType == Enum.UserInputType.Touch then
			dragging = true
			dragStart = input.Position
			startPos = holder.Position
			input.Changed:Connect(function()
				if input.UserInputState == Enum.UserInputState.End then
					dragging = false
				end
			end)
		end
	end)
	connect(UserInputService.InputChanged, function(input)
		if dragging and (input.UserInputType == Enum.UserInputType.MouseMovement
			or input.UserInputType == Enum.UserInputType.Touch) then
			local d = input.Position - dragStart
			holder.Position = UDim2.new(
				startPos.X.Scale, startPos.X.Offset + d.X,
				startPos.Y.Scale, startPos.Y.Offset + d.Y
			)
		end
	end)
end

----------------------------------------------------------------------
-- 7. SIDEBAR + NAVIGASI
----------------------------------------------------------------------
local NAV = {
	{ Name = "Home", Icon = "🏠" },
	{ Name = "Combat", Icon = "⚔️" },
	{ Name = "Glitches", Icon = "🐛" },
	{ Name = "UI Customs", Icon = "🔥" },
	{ Name = "Visual", Icon = "👁️" },
	{ Name = "Misc", Icon = "⚙️" },
}

local sidebar = card(main, {
	Name = "Sidebar",
	Position = UDim2.fromOffset(16, 72),
	Size = UDim2.fromOffset(190, 452),
	BackgroundTransparency = 0.5,
})

local navList = make("Frame", {
	Position = UDim2.fromOffset(10, 12),
	Size = UDim2.new(1, -20, 0, 340),
	BackgroundTransparency = 1,
}, sidebar)
make("UIListLayout", { Padding = UDim.new(0, 8), SortOrder = Enum.SortOrder.LayoutOrder }, navList)

label(sidebar, "RightCtrl  •  toggle UI", 10, {
	AnchorPoint = Vector2.new(0, 1),
	Position = UDim2.new(0, 14, 1, -12),
	Size = UDim2.new(1, -28, 0, 14),
	TextColor3 = Theme.SubText,
})

local Pages = {}
local navButtons = {}
local switchPage -- forward declaration

local function refreshNav()
	for name, nb in pairs(navButtons) do
		local active = (name == State.Page)
		tween(nb.button, 0.3, {
			BackgroundColor3 = active and State.Accent or Color3.new(1, 1, 1),
			BackgroundTransparency = active and 0.2 or 0.92,
		})
		tween(nb.text, 0.3, { TextColor3 = active and Theme.Text or Theme.SubText })
		tween(nb.stroke, 0.3, { Transparency = active and 0.55 or 0.88 })
	end
end

for i, item in ipairs(NAV) do
	local btn = make("TextButton", {
		Name = item.Name,
		LayoutOrder = i,
		Size = UDim2.new(1, 0, 0, 48),
		BackgroundColor3 = Color3.new(1, 1, 1),
		BackgroundTransparency = 0.92,
		AutoButtonColor = false,
		Text = "",
	}, navList)
	make("UICorner", { CornerRadius = UDim.new(0, 14) }, btn)
	local stroke = make("UIStroke", { Color = Color3.new(1, 1, 1), Transparency = 0.88 }, btn)
	pressEffect(btn)

	label(btn, item.Icon, 20, {
		Position = UDim2.fromOffset(14, 0),
		Size = UDim2.new(0, 28, 1, 0),
		TextXAlignment = Enum.TextXAlignment.Center,
	})
	local text = label(btn, item.Name, 15, {
		Font = Theme.FontBold,
		Position = UDim2.fromOffset(52, 0),
		Size = UDim2.new(1, -60, 1, 0),
		TextColor3 = Theme.SubText,
	})

	navButtons[item.Name] = { button = btn, text = text, stroke = stroke }

	connect(btn.MouseEnter, function()
		if State.Page ~= item.Name then tween(btn, 0.2, { BackgroundTransparency = 0.82 }) end
	end)
	connect(btn.MouseLeave, function()
		if State.Page ~= item.Name then tween(btn, 0.2, { BackgroundTransparency = 0.92 }) end
	end)
	connect(btn.MouseButton1Click, function()
		switchPage(item.Name)
	end)
end

onAccent(function() refreshNav() end)

----------------------------------------------------------------------
-- 8. CONTENT AREA & TRANSISI HALAMAN (TweenService)
----------------------------------------------------------------------
local content = make("Frame", {
	Name = "Content",
	Position = UDim2.fromOffset(222, 72),
	Size = UDim2.fromOffset(722, 452),
	BackgroundTransparency = 1,
}, main)

local function createPage(name)
	local page = make("CanvasGroup", {
		Name = name,
		Size = UDim2.fromScale(1, 1),
		BackgroundTransparency = 1,
		GroupTransparency = 1,
		Visible = false,
	}, content)
	Pages[name] = page
	return page
end

function switchPage(name)
	if State.Page == name or not Pages[name] then return end
	local oldName = State.Page
	local old = oldName and Pages[oldName]
	local new = Pages[name]
	State.Page = name
	refreshNav()

	if old then
		tween(old, 0.2, { GroupTransparency = 1, Position = UDim2.fromOffset(-24, 0) })
		task.delay(0.2, function()
			if State.Page ~= oldName then old.Visible = false end
		end)
	end
	new.Visible = true
	new.Position = UDim2.fromOffset(28, 0)
	new.GroupTransparency = 1
	tween(new, 0.38, { GroupTransparency = 0, Position = UDim2.fromOffset(0, 0) })
end

----------------------------------------------------------------------
-- 9. HALAMAN HOME (profil + statistik + vitals)
----------------------------------------------------------------------
local healthUpdaters = {}

local function setHealth(percent)
	percent = math.clamp(math.floor(percent + 0.5), 0, 100)
	for _, fn in ipairs(healthUpdaters) do fn(percent) end
end

local function formatTime(seconds)
	return string.format("%d:%02d", math.floor(seconds / 60), seconds % 60)
end

local function buildProfile(page)
	local profile = card(page, { Size = UDim2.new(1, 0, 0, 176), ClipsDescendants = true })

	-- Karakter anime (menyatu dengan UI lewat gradient transparansi)
	local char = make("ImageLabel", {
		Name = "AnimeCharacter",
		AnchorPoint = Vector2.new(1, 1),
		Position = UDim2.fromScale(1, 1),
		Size = UDim2.fromScale(0.55, 1),
		BackgroundTransparency = 1,
		Image = CONFIG.AnimeImage,
		ImageTransparency = 0.05,
		ScaleType = Enum.ScaleType.Crop,
		Visible = CONFIG.AnimeImage ~= "",
	}, profile)
	make("UIGradient", {
		Transparency = NumberSequence.new({
			NumberSequenceKeypoint.new(0, 1),
			NumberSequenceKeypoint.new(0.45, 0.4),
			NumberSequenceKeypoint.new(1, 0),
		}),
	}, char)

	-- Avatar lingkaran
	local avatarFrame = make("Frame", {
		AnchorPoint = Vector2.new(0, 0.5),
		Position = UDim2.new(0, 22, 0.5, 0),
		Size = UDim2.fromOffset(108, 108),
		BackgroundColor3 = Theme.Deep,
		BackgroundTransparency = 0.3,
	}, profile)
	make("UICorner", { CornerRadius = UDim.new(1, 0) }, avatarFrame)
	local avStroke = make("UIStroke", { Thickness = 2.5, Color = State.Accent }, avatarFrame)
	onAccent(function(c) avStroke.Color = c end)

	local avatar = make("ImageLabel", {
		Size = UDim2.fromScale(1, 1),
		BackgroundTransparency = 1,
		Image = "",
	}, avatarFrame)
	make("UICorner", { CornerRadius = UDim.new(1, 0) }, avatar)

	task.spawn(function()
		local ok, img = pcall(function()
			return Players:GetUserThumbnailAsync(
				player.UserId, Enum.ThumbnailType.HeadShot, Enum.ThumbnailSize.Size150x150)
		end)
		if ok and State.Alive then avatar.Image = img end
	end)

	-- Nama + verified
	local nameRow = make("Frame", {
		Position = UDim2.fromOffset(148, 48),
		Size = UDim2.fromOffset(300, 30),
		BackgroundTransparency = 1,
	}, profile)
	make("UIListLayout", {
		FillDirection = Enum.FillDirection.Horizontal,
		VerticalAlignment = Enum.VerticalAlignment.Center,
		Padding = UDim.new(0, 8),
	}, nameRow)

	label(nameRow, player.DisplayName, 24, {
		Font = Theme.FontBold,
		AutomaticSize = Enum.AutomaticSize.X,
		Size = UDim2.fromOffset(0, 30),
		LayoutOrder = 1,
	})
	local badge = make("TextLabel", {
		LayoutOrder = 2,
		Size = UDim2.fromOffset(22, 22),
		BackgroundColor3 = State.Accent,
		Text = "✓",
		TextSize = 13,
		Font = Theme.FontBold,
		TextColor3 = Color3.new(1, 1, 1),
	}, nameRow)
	make("UICorner", { CornerRadius = UDim.new(1, 0) }, badge)
	onAccent(function(c) badge.BackgroundColor3 = c end)

	local sub = label(profile, CONFIG.ProfileSubtitle, 14, {
		Font = Theme.FontBold,
		Position = UDim2.fromOffset(148, 84),
		Size = UDim2.fromOffset(300, 18),
		TextColor3 = State.Accent,
	})
	onAccent(function(c) sub.TextColor3 = c end)

	label(profile, "@" .. player.Name, 12, {
		Position = UDim2.fromOffset(148, 106),
		Size = UDim2.fromOffset(300, 16),
		TextColor3 = Theme.SubText,
	})
end

local function buildStatCard(parent, order, icon, title, value)
	local c = card(parent, { LayoutOrder = order, Size = UDim2.new(0.25, -10.5, 1, 0) })

	local chip = make("Frame", {
		Position = UDim2.fromOffset(14, 14),
		Size = UDim2.fromOffset(38, 38),
		BackgroundColor3 = State.Accent,
		BackgroundTransparency = 0.75,
	}, c)
	make("UICorner", { CornerRadius = UDim.new(0, 12) }, chip)
	onAccent(function(col) chip.BackgroundColor3 = col end)
	label(chip, icon, 18, {
		Size = UDim2.fromScale(1, 1),
		TextXAlignment = Enum.TextXAlignment.Center,
	})

	label(c, string.upper(title), 11, {
		Font = Theme.FontBold,
		Position = UDim2.fromOffset(62, 14),
		Size = UDim2.new(1, -70, 0, 38),
		TextColor3 = Theme.SubText,
	})
	return label(c, value, 28, {
		Font = Theme.FontBold,
		Position = UDim2.fromOffset(14, 62),
		Size = UDim2.new(1, -28, 0, 34),
	})
end

local function buildHome()
	local page = createPage("Home")
	buildProfile(page)

	local statsRow = make("Frame", {
		Position = UDim2.fromOffset(0, 190),
		Size = UDim2.new(1, 0, 0, 108),
		BackgroundTransparency = 1,
	}, page)
	make("UIListLayout", {
		FillDirection = Enum.FillDirection.Horizontal,
		Padding = UDim.new(0, 14),
		SortOrder = Enum.SortOrder.LayoutOrder,
	}, statsRow)

	buildStatCard(statsRow, 1, "💰", "Bounty", CONFIG.Stats.Bounty)
	buildStatCard(statsRow, 2, "⭐", "Level", CONFIG.Stats.Level)
	local timeLabel = buildStatCard(statsRow, 3, "⏱️", "Time", formatTime(CONFIG.Stats.StartSeconds))
	local healthLabel = buildStatCard(statsRow, 4, "❤️", "Health", CONFIG.Stats.Health .. "%")

	-- Timer berjalan
	task.spawn(function()
		local t = CONFIG.Stats.StartSeconds
		while State.Alive do
			timeLabel.Text = formatTime(t)
			t += 1
			task.wait(1)
		end
	end)

	-- Vitals
	local vitals = card(page, { Position = UDim2.fromOffset(0, 312), Size = UDim2.new(1, 0, 0, 140) })
	label(vitals, "Vitals", 18, {
		Font = Theme.FontBold, Position = UDim2.fromOffset(18, 14), Size = UDim2.new(1, -36, 0, 22),
	})
	label(vitals, "Live status overview", 12, {
		Position = UDim2.fromOffset(18, 38), Size = UDim2.new(1, -36, 0, 16), TextColor3 = Theme.SubText,
	})

	local track = make("Frame", {
		Position = UDim2.fromOffset(18, 78),
		Size = UDim2.new(1, -36, 0, 12),
		BackgroundColor3 = Color3.new(1, 1, 1),
		BackgroundTransparency = 0.88,
	}, vitals)
	make("UICorner", { CornerRadius = UDim.new(1, 0) }, track)
	local fill = make("Frame", {
		Size = UDim2.fromScale(0, 1),
		BackgroundColor3 = State.Accent,
		BorderSizePixel = 0,
	}, track)
	make("UICorner", { CornerRadius = UDim.new(1, 0) }, fill)
	make("UIGradient", {
		Color = ColorSequence.new(Color3.fromRGB(150, 210, 255), Color3.new(1, 1, 1)),
	}, fill)
	onAccent(function(c) fill.BackgroundColor3 = c end)

	local pct = label(vitals, "", 13, {
		Font = Theme.FontBold, Position = UDim2.fromOffset(18, 100), Size = UDim2.new(1, -36, 0, 18),
		TextColor3 = Theme.SubText,
	})

	table.insert(healthUpdaters, function(p)
		healthLabel.Text = p .. "%"
		pct.Text = "Health " .. p .. "%  •  " .. (p >= 50 and "Stable" or "Low")
		tween(fill, 0.6, { Size = UDim2.fromScale(p / 100, 1) })
	end)
	setHealth(CONFIG.Stats.Health)

	if CONFIG.UseLiveHealth then
		local function bind(char)
			local hum = char:WaitForChild("Humanoid", 5)
			if not hum then return end
			setHealth(hum.Health / hum.MaxHealth * 100)
			connect(hum.HealthChanged, function()
				setHealth(hum.Health / hum.MaxHealth * 100)
			end)
		end
		if player.Character then task.spawn(bind, player.Character) end
		connect(player.CharacterAdded, bind)
	end
end

----------------------------------------------------------------------
-- 10. KOMPONEN HALAMAN LIST (toggle, tombol, swatch)
----------------------------------------------------------------------
local function createToggle(parent, order, def)
	local row = card(parent, { LayoutOrder = order, Size = UDim2.new(1, -6, 0, 60) })
	label(row, def.title, 15, {
		Font = Theme.FontBold, Position = UDim2.fromOffset(18, 10), Size = UDim2.new(1, -100, 0, 20),
	})
	label(row, def.desc or "", 12, {
		Position = UDim2.fromOffset(18, 32), Size = UDim2.new(1, -100, 0, 16), TextColor3 = Theme.SubText,
	})

	local track = make("Frame", {
		AnchorPoint = Vector2.new(1, 0.5),
		Position = UDim2.new(1, -18, 0.5, 0),
		Size = UDim2.fromOffset(48, 28),
		BackgroundColor3 = Theme.Off,
	}, row)
	make("UICorner", { CornerRadius = UDim.new(1, 0) }, track)
	local knob = make("Frame", {
		AnchorPoint = Vector2.new(0, 0.5),
		Position = UDim2.new(0, 3, 0.5, 0),
		Size = UDim2.fromOffset(22, 22),
		BackgroundColor3 = Color3.new(1, 1, 1),
	}, track)
	make("UICorner", { CornerRadius = UDim.new(1, 0) }, knob)

	local on = def.default == true
	local function render(animate)
		local t = animate and 0.25 or 0
		tween(track, t, { BackgroundColor3 = on and State.Accent or Theme.Off })
		tween(knob, t, {
			Position = on and UDim2.new(1, -25, 0.5, 0) or UDim2.new(0, 3, 0.5, 0),
		}, Enum.EasingStyle.Back)
	end
	render(false)
	onAccent(function() render(false) end)

	local hit = make("TextButton", { Size = UDim2.fromScale(1, 1), BackgroundTransparency = 1, Text = "" }, row)
	pressEffect(hit)
	connect(hit.MouseButton1Click, function()
		on = not on
		render(true)
		if def.callback then task.spawn(def.callback, on) end
	end)
	if on and def.callback then task.spawn(def.callback, on) end
end

local function createAction(parent, order, def)
	local row = card(parent, { LayoutOrder = order, Size = UDim2.new(1, -6, 0, 60) })
	label(row, def.title, 15, {
		Font = Theme.FontBold, Position = UDim2.fromOffset(18, 10), Size = UDim2.new(1, -150, 0, 20),
	})
	label(row, def.desc or "", 12, {
		Position = UDim2.fromOffset(18, 32), Size = UDim2.new(1, -150, 0, 16), TextColor3 = Theme.SubText,
	})
	local b = make("TextButton", {
		AnchorPoint = Vector2.new(1, 0.5),
		Position = UDim2.new(1, -18, 0.5, 0),
		Size = UDim2.fromOffset(100, 34),
		BackgroundColor3 = State.Accent,
		BackgroundTransparency = 0.2,
		Text = def.button or "Run",
		TextSize = 14,
		Font = Theme.FontBold,
		TextColor3 = Theme.Text,
		AutoButtonColor = false,
	}, row)
	make("UICorner", { CornerRadius = UDim.new(0, 12) }, b)
	onAccent(function(c) b.BackgroundColor3 = c end)
	pressEffect(b)
	connect(b.MouseEnter, function() tween(b, 0.2, { BackgroundTransparency = 0 }) end)
	connect(b.MouseLeave, function() tween(b, 0.2, { BackgroundTransparency = 0.2 }) end)
	connect(b.MouseButton1Click, function()
		if def.callback then task.spawn(def.callback) end
	end)
end

local function createSwatches(parent, order, def)
	local row = card(parent, { LayoutOrder = order, Size = UDim2.new(1, -6, 0, 92) })
	label(row, def.title, 15, {
		Font = Theme.FontBold, Position = UDim2.fromOffset(18, 10), Size = UDim2.new(1, -36, 0, 20),
	})
	label(row, def.desc or "", 12, {
		Position = UDim2.fromOffset(18, 32), Size = UDim2.new(1, -36, 0, 16), TextColor3 = Theme.SubText,
	})
	local holderF = make("Frame", {
		Position = UDim2.fromOffset(18, 54), Size = UDim2.new(1, -36, 0, 28), BackgroundTransparency = 1,
	}, row)
	make("UIListLayout", {
		FillDirection = Enum.FillDirection.Horizontal, Padding = UDim.new(0, 10),
	}, holderF)

	for _, color in ipairs(def.colors) do
		local s = make("TextButton", {
			Size = UDim2.fromOffset(28, 28), BackgroundColor3 = color, Text = "", AutoButtonColor = false,
		}, holderF)
		make("UICorner", { CornerRadius = UDim.new(1, 0) }, s)
		make("UIStroke", { Color = Color3.new(1, 1, 1), Transparency = 0.5, Thickness = 1.5 }, s)
		pressEffect(s)
		connect(s.MouseButton1Click, function() setAccent(color) end)
	end
end

local function buildListPage(name, def)
	local page = createPage(name)
	label(page, def.title, 24, { Font = Theme.FontBold, Size = UDim2.new(1, 0, 0, 30) })
	label(page, def.subtitle, 13, {
		Position = UDim2.fromOffset(0, 32), Size = UDim2.new(1, 0, 0, 18), TextColor3 = Theme.SubText,
	})

	local scroll = make("ScrollingFrame", {
		Position = UDim2.fromOffset(0, 66),
		Size = UDim2.new(1, 0, 1, -66),
		BackgroundTransparency = 1,
		BorderSizePixel = 0,
		ScrollBarThickness = 3,
		ScrollBarImageColor3 = State.Accent,
		AutomaticCanvasSize = Enum.AutomaticSize.Y,
		CanvasSize = UDim2.new(),
	}, page)
	make("UIListLayout", { Padding = UDim.new(0, 10), SortOrder = Enum.SortOrder.LayoutOrder }, scroll)
	make("UIPadding", { PaddingBottom = UDim.new(0, 8) }, scroll)
	onAccent(function(c) scroll.ScrollBarImageColor3 = c end)

	for i, item in ipairs(def.items) do
		if item.type == "toggle" then
			createToggle(scroll, i, item)
		elseif item.type == "action" then
			createAction(scroll, i, item)
		elseif item.type == "swatches" then
			createSwatches(scroll, i, item)
		end
	end
end

----------------------------------------------------------------------
-- 11. DEFINISI HALAMAN & AKSI (tambah fitur di sini)
----------------------------------------------------------------------
local original = {
	Brightness = Lighting.Brightness,
	Ambient = Lighting.Ambient,
	ClockTime = Lighting.ClockTime,
}

local PAGE_DEFS = {
	Combat = {
		title = "Combat", subtitle = "Pengaturan pertarungan (hubungkan ke sistem game Anda)",
		items = {
			{ type = "toggle", title = "Aim Assist", desc = "Hook: isi callback dengan sistem Anda",
				callback = function(on) print("[TheRichHUB] Aim Assist:", on) end },
			{ type = "toggle", title = "Hit Indicator", desc = "Tampilkan indikator serangan",
				callback = function(on) print("[TheRichHUB] Hit Indicator:", on) end },
			{ type = "toggle", title = "Target Lock", desc = "Kunci target terdekat",
				callback = function(on) print("[TheRichHUB] Target Lock:", on) end },
		},
	},
	Glitches = {
		title = "Glitches", subtitle = "Opsi stabilitas & debugging",
		items = {
			{ type = "toggle", title = "Stabilizer", desc = "Mengurangi jitter karakter",
				callback = function(on) print("[TheRichHUB] Stabilizer:", on) end },
			{ type = "toggle", title = "Smooth Animations", desc = "Transisi animasi lebih halus",
				callback = function(on) print("[TheRichHUB] Smooth Animations:", on) end },
			{ type = "toggle", title = "Lag Guard", desc = "Mode hemat performa",
				callback = function(on) print("[TheRichHUB] Lag Guard:", on) end },
		},
	},
	["UI Customs"] = {
		title = "UI Customs", subtitle = "Personalisasi tampilan TheRichHUB",
		items = {
			{ type = "swatches", title = "Accent Color", desc = "Ubah warna highlight UI",
				colors = {
					Color3.fromRGB(64, 156, 255), Color3.fromRGB(140, 110, 255),
					Color3.fromRGB(0, 214, 190), Color3.fromRGB(255, 120, 170),
					Color3.fromRGB(255, 170, 60),
				} },
			{ type = "toggle", title = "Background Blur", desc = "Blur dunia 3D di belakang UI", default = true,
				callback = function(on) State.BlurEnabled = on; updateBlur() end },
			{ type = "toggle", title = "Compact Mode", desc = "Perkecil ukuran UI 15%",
				callback = function(on) State.ScaleMul = on and 0.85 or 1; updateResponsiveScale() end },
		},
	},
	Visual = {
		title = "Visual", subtitle = "Efek visual lokal (hanya di layar Anda)",
		items = {
			{ type = "toggle", title = "Fullbright", desc = "Terangkan seluruh dunia",
				callback = function(on)
					Lighting.Brightness = on and 3 or original.Brightness
					Lighting.Ambient = on and Color3.new(1, 1, 1) or original.Ambient
				end },
			{ type = "toggle", title = "Wide FOV", desc = "Field of view 90°",
				callback = function(on)
					local cam = workspace.CurrentCamera
					if cam then cam.FieldOfView = on and 90 or 70 end
				end },
			{ type = "toggle", title = "Night Mode", desc = "Ubah waktu menjadi malam",
				callback = function(on) Lighting.ClockTime = on and 0 or original.ClockTime end },
		},
	},
	Misc = {
		title = "Misc", subtitle = "Utilitas tambahan",
		items = {
			{ type = "action", title = "Reset Character", desc = "Respawn karakter Anda", button = "Reset",
				callback = function()
					local char = player.Character
					local hum = char and char:FindFirstChildOfClass("Humanoid")
					if hum then hum.Health = 0 end
				end },
			{ type = "action", title = "Rejoin Server", desc = "Masuk ulang ke server ini", button = "Rejoin",
				callback = function() TeleportService:Teleport(game.PlaceId, player) end },
		},
	},
}

----------------------------------------------------------------------
-- 12. MINIMIZE / CLOSE / REOPEN
----------------------------------------------------------------------
local reopen = make("TextButton", {
	Name = "Reopen",
	AnchorPoint = Vector2.new(0, 0.5),
	Position = UDim2.new(0, 16, 0.5, 0),
	Size = UDim2.fromOffset(54, 54),
	BackgroundColor3 = Theme.Glass,
	BackgroundTransparency = 0.35,
	Text = "",
	AutoButtonColor = false,
	Visible = false,
}, gui)
make("UICorner", { CornerRadius = UDim.new(1, 0) }, reopen)
local reopenStroke = make("UIStroke", { Color = State.Accent, Transparency = 0.3, Thickness = 1.5 }, reopen)
onAccent(function(c) reopenStroke.Color = c end)
createLogo(reopen, 26)
local reopenScale = make("UIScale", { Scale = 0 }, reopen)

local function showMain()
	State.Minimized = false
	main.Visible = true
	tween(main, 0.4, { GroupTransparency = 0 })
	tween(mainScale, 0.45, { Scale = 1 }, Enum.EasingStyle.Back)
	tween(reopenScale, 0.2, { Scale = 0 })
	task.delay(0.2, function() if not State.Minimized then reopen.Visible = false end end)
	updateBlur()
end

local function hideMain()
	State.Minimized = true
	tween(main, 0.3, { GroupTransparency = 1 })
	tween(mainScale, 0.3, { Scale = 0.92 })
	task.delay(0.3, function() if State.Minimized then main.Visible = false end end)
	reopen.Visible = true
	tween(reopenScale, 0.4, { Scale = 1 }, Enum.EasingStyle.Back)
	updateBlur()
end

local function closeUI()
	State.Alive = false
	tween(main, 0.3, { GroupTransparency = 1 })
	tween(mainScale, 0.3, { Scale = 0.9 })
	tween(blur, 0.3, { Size = 0 })
	task.wait(0.35)
	for _, c in ipairs(connections) do c:Disconnect() end
	-- kembalikan efek lokal
	Lighting.Brightness = original.Brightness
	Lighting.Ambient = original.Ambient
	blur:Destroy()
	gui:Destroy()
end

connect(minimizeBtn.MouseButton1Click, hideMain)
connect(closeBtn.MouseButton1Click, closeUI)
connect(reopen.MouseButton1Click, showMain)
pressEffect(reopen)

connect(UserInputService.InputBegan, function(input, processed)
	if processed then return end
	if input.KeyCode == CONFIG.ToggleKey then
		if State.Minimized then showMain() else hideMain() end
	end
end)

----------------------------------------------------------------------
-- 13. INIT
----------------------------------------------------------------------
buildHome()
for _, item in ipairs(NAV) do
	if PAGE_DEFS[item.Name] then
		buildListPage(item.Name, PAGE_DEFS[item.Name])
	end
end

updateResponsiveScale()
local cam = workspace.CurrentCamera
if cam then
	connect(cam:GetPropertyChangedSignal("ViewportSize"), updateResponsiveScale)
end

switchPage("Home")
showMain()
